# Java 8 新特性(八)：CompletableFuture类

[toc]



## 参考内容

【1】[使用CompletableFuture.allOf实现异步执行同步搜集结果](https://blog.csdn.net/teachy/article/details/104971814)